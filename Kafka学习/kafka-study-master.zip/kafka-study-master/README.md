## kafka 的项目工程

- [kafka-example](https://github.com/xuwujing/kafka/tree/master/kafka-example) :kafka 的 HelloWord 工程。producer和consumer的相关代码示例。

- [kafka-consumerExample](https://github.com/xuwujing/kafka/tree/master/kafka-consumerExample):kafka consumer 手动提交测试代码示例。

- [kafka-storm](https://github.com/xuwujing/kafka/tree/master/kafka-storm):kafka整合 storm的工程示例。

## kafka 的相关文章

-  [kafka demo](http://blog.csdn.net/qazwsxpcm/article/details/79186668)
-  [kafka consumer](http://blog.csdn.net/qazwsxpcm/article/details/79293200)
