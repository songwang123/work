 kafka producer和consumer的demo。
 关于demo讲解，博客地址为:http://www.cnblogs.com/xuwujing/p/8371127.html
