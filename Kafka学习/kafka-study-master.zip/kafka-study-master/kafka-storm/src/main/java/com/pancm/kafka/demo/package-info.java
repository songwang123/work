/**
 * 
 */
/**
 * @Title: package-info
 * @Description: 
 * kafka 的demo
 * @Version:1.0.0  
 * @author pancm
 * @date 2018年4月19日
 */
package com.pancm.kafka.demo;